@echo off
:: MK-Muse professional launcher: system Node fast-path, else portable
:: Node v24.14.0 auto-fetch, pinned parts, clean errors. No admin needed.
title MK - Muse OTP Sender
cd /d "%~dp0"
echo ==================================================
echo   MK - MUSE OTP SENDER  v2.0  (license-free)
echo ==================================================
echo.
set NODE=
set NPM=
set SYSV=
set RUNTIME=%~dp0runtime
set NV=node-v24.14.0-win-x64
set NZIP=%RUNTIME%\%NV%.zip
where node >nul 2>nul
if not errorlevel 1 for /f "delims=" %%v in ('node -v 2^>nul') do set SYSV=%%v
if "%SYSV%"=="v24.14.0" (
  echo [OK] System Node v24.14.0 found, using it.
  set NODE=node
  set NPM=npm
)
if not defined NODE (
  if not exist "%RUNTIME%\%NV%\node.exe" (
    echo [*] Node v24.14.0 not found, fetching portable runtime once, ~26 MB...
    if not exist "%RUNTIME%" mkdir "%RUNTIME%"
    where curl >nul 2>nul
    if not errorlevel 1 (
      curl -L --fail --retry 2 -o "%NZIP%" "https://nodejs.org/dist/v24.14.0/%NV%.zip"
    ) else (
      powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://nodejs.org/dist/v24.14.0/%NV%.zip' -OutFile '%NZIP%'"
    )
    if errorlevel 1 (
      echo [X] Download failed. Check internet and run again.
      pause
      exit /b 1
    )
    echo [*] Unpacking runtime...
    where tar >nul 2>nul
    if not errorlevel 1 (
      tar -xf "%NZIP%" -C "%RUNTIME%"
    ) else (
      powershell -NoProfile -Command "Expand-Archive -Path '%NZIP%' -DestinationPath '%RUNTIME%' -Force"
    )
    if errorlevel 1 (
      echo [X] Unpack failed. Delete the runtime folder and run again.
      pause
      exit /b 1
    )
    del "%NZIP%" >nul 2>nul
    if not exist "%RUNTIME%\%NV%\node.exe" (
      echo [X] Runtime broken after unpack. Delete the runtime folder and run again.
      pause
      exit /b 1
    )
  )
  set NODE=%RUNTIME%\%NV%\node.exe
  set NPM=%RUNTIME%\%NV%\npm.cmd
  echo [OK] Portable Node v24.14.0 ready.
)
if not exist "node_modules\bytenode\package.json" (
  echo [*] Installing parts, one moment...
  call "%NPM%" i --no-bin-links --no-audit --no-fund bytenode@1.6.0 chalk@4.1.2 https-proxy-agent@9.1.0 socks-proxy-agent@10.1.0
  if errorlevel 1 (
    echo [X] Parts install failed. Check internet and run again.
    pause
    exit /b 1
  )
  if not exist "node_modules\bytenode\package.json" (
    echo [X] Parts still missing after install. Screenshot this and ask for help.
    pause
    exit /b 1
  )
)
echo [OK] Parts ready.
echo [^>] Launching Muse...
"%NODE%" muse_win.js %*
set EC=%ERRORLEVEL%
if not "%EC%"=="0" (
  echo.
  echo [X] Muse stopped with code %EC%. Screenshot this window if you need help.
  pause
)
exit /b %EC%
