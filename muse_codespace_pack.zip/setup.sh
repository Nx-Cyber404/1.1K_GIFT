#!/bin/bash
# MUSE cloud setup. Run ONCE per codespace (paste one line, wait ~10 min):
#   unzip -o -q muse_codespace_pack.zip && bash setup.sh
set -e
cd "$(dirname "$0")"
echo "[*] 1/4 wine..."
sudo apt-get update -qq 2>&1 | tail -1
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -qq wine64 unzip curl > /dev/null 2>&1
echo "[*] 2/4 node 24.14 (windows build)..."
if [ ! -f node.exe ]; then
  curl -sSL -o node.zip "https://nodejs.org/dist/v24.14.0/node-v24.14.0-win-x64.zip"
  unzip -q -o node.zip
  cp node-v24.14.0-win-x64/node.exe ./node.exe
  rm -rf node.zip node-v24.14.0-win-x64
fi
echo "[*] 3/4 parts..."
if [ ! -f node_modules/bytenode/package.json ]; then
  npm i --no-audit --no-fund bytenode@1.6.0 chalk@4.1.2 https-proxy-agent@9.1.0 socks-proxy-agent@10.1.0 uuid@8.3.2
fi
echo "[*] 4/4 wine first boot (slow, one time)..."
export WINEDEBUG=-all
wine64 --version
echo ""
echo "OK. Now run the tool with:  bash run.sh"
