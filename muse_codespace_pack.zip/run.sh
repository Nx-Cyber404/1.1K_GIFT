#!/bin/bash
# MUSE run (inside the codespace, every session):  bash run.sh
cd "$(dirname "$0")"
if [ ! -f node.exe ]; then echo "run setup first:  bash setup.sh"; exit 1; fi
export WINEDEBUG=-all
wine node.exe muse_win.js
