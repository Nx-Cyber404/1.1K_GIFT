// muse_win.js — FINAL launcher (silent). Bytecode-locked to Node v24.14.0.
'use strict';
if (process.version !== 'v24.14.0') {
  console.error('[!] This build needs Node.js v24.14.0 exactly (you have ' + process.version + ').');
  console.error('    Install it from https://nodejs.org/dist/v24.14.0/ then run again.');
  process.exit(6);
}
const path = require('path');
const fs = require('fs');
const HERE = __dirname;
try { require(path.join(HERE, 'muse_shim.js')); }
catch (e) {
  console.error('[!] muse_shim.js is missing next to the launcher. Re-extract the zip.');
  process.exit(7);
}
try { require('bytenode'); }
catch (e) {
  console.error('[!] Parts missing. Run: npm i bytenode@1.6.0 chalk@4.1.2 https-proxy-agent@9.1.0 socks-proxy-agent@10.1.0');
  process.exit(8);
}
const JSC = ['muse.jsc', 'muse_fixed.jsc']
  .map(f => path.join(HERE, f))
  .find(p => { try { return fs.statSync(p).isFile(); } catch (e) { return false; } });
if (!JSC) {
  console.error('[!] muse.jsc not found next to the launcher. Re-extract the zip.');
  process.exit(9);
}
try {
  require(JSC);
} catch (e) {
  console.error('[!] The tool failed to start: ' + (e && e.message));
  process.exit(10);
}
