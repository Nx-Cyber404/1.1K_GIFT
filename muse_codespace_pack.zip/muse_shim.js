// muse_shim.js — FINAL (silent). License-free runtime for MK-Muse.
// - HWID: real hardware first, seamless fake fallback (Wine/VMs)
// - License + heartbeat: answered locally, vendor server never contacted
// - No output, no logs. Loaded by muse_win.js.
'use strict';
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const CANNED = JSON.stringify({ status: 'active', sig: 'OFFLINE', token: 'OFFLINE-BYPASS-TOKEN', user: 'Licensed' });
const PING = JSON.stringify({ status: 'active' });
// same-vendor Ed25519 key prefix (scraper family)
const PUBPREFIX = 'MCowBQYDK2VwAyEAIU7Pc75ao+Fn7XGC7kFGeDh7JAs3o4NSL2Lgm';
function isLicensePath(u) {
  const s = String(u || '');
  return s.includes('/api/verify') || s.includes('/api/ping') || s.includes('/api/kill') ||
         s.includes('api/verify') || s.includes('api/ping') || s.toLowerCase().includes('license');
}
function fakeCall(a, canned) {
  const cb = a.find(x => typeof x === 'function');
  const EE = require('events');
  const req = new EE();
  req.write = () => true;
  req.end = () => { req.emit('finish'); };
  req.destroy = () => {}; req.setTimeout = () => {};
  req.setHeader = () => {}; req.getHeader = () => undefined; req.abort = () => {};
  process.nextTick(() => {
    const res = new EE();
    res.statusCode = 200; res.headers = { 'content-type': 'application/json' };
    if (cb) cb(res);
    res.emit('data', canned); res.emit('end');
  });
  return req;
}
function wrap(mod) {
  for (const fn of ['request', 'get']) {
    const o = mod[fn];
    mod[fn] = function (...a) {
      let u = '';
      try {
        const x = a[0];
        if (typeof x === 'string' || x instanceof URL) u = String(x);
        else if (x && typeof x === 'object') u = (x.protocol || '') + '//' + (x.host || x.hostname || '') + (x.path || x.pathname || '/');
      } catch (e) { /* fall through to real call */ }
      if (u && isLicensePath(u)) return fakeCall(a, u.includes('ping') ? PING : CANNED);
      return o.apply(this, a);
    };
  }
}
wrap(http); wrap(https);
// global fetch (undici) does NOT go through http module — hook separately
try {
  if (typeof globalThis.fetch === 'function') {
    const oFetch = globalThis.fetch;
    globalThis.fetch = function (input, init) {
      let u = '';
      try { u = typeof input === 'string' ? input : (input && input.url ? input.url : String(input)); } catch (e) {}
      if (u && isLicensePath(u)) {
        try { return Promise.resolve(new Response(u.includes('ping') ? PING : CANNED, { status: 200, headers: { 'content-type': 'application/json' } })); }
        catch (e) { /* fall through to real call */ }
      }
      return oFetch.apply(this, arguments);
    };
  }
} catch (e) {}
// license Ed25519 verify -> true (scoped; normal crypto untouched)
const oVerify = crypto.verify;
crypto.verify = function (alg, data, key, sig) {
  try {
    let ds = '';
    try { ds = Buffer.isBuffer(data) ? data.toString('utf8') : String(data); } catch (e) {}
    let ks = '';
    try { ks = typeof key === 'string' ? key : (key && key.export ? key.export({ type: 'spki', format: 'pem' }).toString() : ''); } catch (e) {}
    if (alg === null || alg === undefined) return true;   // license-signature shape
    if (ks && ks.includes(PUBPREFIX)) return true;        // vendor key
    if ((ds.match(/\|/g) || []).length >= 2) return true; // HWID|app|ver|ts blob
    if (/SKING-/i.test(ds)) return true;                  // muse HWID prefix
    if (/ANKING-/i.test(ds)) return true;                 // family HWID
  } catch (e) { /* fall through */ }
  return oVerify.apply(this, arguments);
};
globalThis.window = globalThis;
// purge guard: block deletes of tool/shim/gate files
try {
  const _fs = require('fs');
  const guarded = p => typeof p === 'string' && /(\.js|\.jsc|\.sh|\.cfg|\.txt)$/.test(p);
  for (const m of ['unlinkSync', 'rmSync']) {
    const o = _fs[m];
    _fs[m] = function (p, ...r) { if (guarded(p)) return; return o.call(this, p, ...r); };
  }
  for (const m of ['unlink', 'rm']) {
    const o = _fs[m];
    _fs[m] = function (p, ...r) {
      if (guarded(p)) {
        const cb = r[r.length - 1];
        if (typeof cb === 'function') process.nextTick(cb);
        return;
      }
      return o.call(this, p, ...r);
    };
  }
} catch (e) {}
// spawn guard: node children inherit the bypass
try {
  const cp = require('child_process');
  const SHIM = __filename;
  const isNode = c => /node(\.exe)?$/i.test(String(c)) || c === 'nodejs';
  const inj = a => {
    if (!isNode(a[0])) return a;
    if (Array.isArray(a[1])) a[1] = ['-r', SHIM].concat(a[1]);
    else a.splice(1, 0, ['-r', SHIM]);
    return a;
  };
  for (const m of ['spawn', 'spawnSync']) {
    const o = cp[m];
    cp[m] = function (...a) { return o.apply(this, inj(a)); };
  }
  const oe = cp.execFile;
  cp.execFile = function (...a) { return oe.apply(this, inj(a)); };
} catch (e) {}
// ---- HWID: real hardware first, seamless fake fallback ----
const FAKE_UUID = '4C4C4544-0056-4710-8033-CAC04F4D3332';
const FAKE_GUID = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';
const FAKE_CPU = 'BFEBFBFF000906A3';
const FAKE_VOL = '1A2B3C4D';
const FAKE_MB = 'MB1234567890ABCD';
const FAKE_HOST = 'DESKTOP-ABC1234';
const FAKE_MAC = '00:11:22:33:44:55';
// exact shape the tool wants: MachineGuid|ProcessorId|VolumeSerial|BaseBoardSerial
const FAKE_PIPE = FAKE_GUID + '|' + FAKE_CPU + '|' + FAKE_VOL + '|' + FAKE_MB + '\r\n';
function fakeFor(cmd) {
  const s = String(cmd).toLowerCase();
  if (s.includes('wmic')) {
    if (s.includes('computersystemproduct') || s.includes('csproduct')) return 'UUID  \r\n' + FAKE_UUID + '\r\n';
    if (s.includes('cpu') && s.includes('processorid')) return 'ProcessorId  \r\n' + FAKE_CPU + '\r\n';
    if (s.includes('diskdrive') && s.includes('serial')) return 'SerialNumber  \r\nWD-WCC4N1234567\r\n';
    if (s.includes('baseboard')) return 'SerialNumber  \r\n' + FAKE_MB + '\r\n';
    if (s.includes('bios')) return 'SerialNumber  \r\nABC1234567\r\n';
    return FAKE_UUID + '\r\n';
  }
  if (s.includes('reg') && s.includes('query') && (s.includes('machineguid') || s.includes('cryptography')))
    return '\r\nHKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography\r\n    MachineGuid    REG_SZ    ' + FAKE_GUID + '\r\n';
  if (s.includes('powershell') || s.includes('pwsh')) {
    if ((s.includes('machineguid') && s.includes('processorid')) || (s.includes('-join') && s.includes('|'))) return FAKE_PIPE;
    if (s.includes('win32_computersystemproduct') || s.includes('uuid')) return FAKE_UUID + '\r\n';
    if (s.includes('machineguid')) return FAKE_GUID + '\r\n';
    return null;
  }
  if (/(^|[\s&|;])vol(\s|$)/.test(s)) return ' Volume in drive C is Windows\r\n Volume Serial Number is 1A2B-3C4D\r\n';
  if (/(^|[\s&|;])hostname(\s|$)/.test(s) || s.includes('hostname.exe')) return FAKE_HOST + '\r\n';
  if (s.includes('getmac')) return 'Physical Address    Transport Name                   \r\n=================== ==========================================\r\n00-11-22-33-44-55   \\Device\\Tcpip_{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}\r\n';
  if (s.includes('whoami')) return 'desktop-abc1234\\user\r\n';
  return null;
}
// the tool's HWID shape: 4+ pipe-joined non-empty parts
function validPipe(s) {
  try {
    const p = String(s).replace(/^﻿/, '').trim().split('|');
    return p.length >= 4 && p.slice(0, 4).every(x => x.trim().length > 0);
  } catch (e) { return false; }
}
// real powershell-on-pipe emits UTF-16LE; accept UTF-8 too
function decodeReal(buf) {
  const cands = [];
  try { cands.push(buf.toString('utf16le')); } catch (e) {}
  try { cands.push(buf.toString('utf8')); } catch (e) {}
  for (const s of cands) if (validPipe(s)) return s;
  return null;
}
function isPipeCmd(cmd) {
  const s = String(cmd).toLowerCase();
  return (s.includes('powershell') || s.includes('pwsh')) &&
    ((s.includes('machineguid') && s.includes('processorid')) || (s.includes('-join') && s.includes('|')));
}
// encoded request -> exact decoded STRING; raw request -> real-shaped UTF-16LE bytes
function asRet(str, a) {
  let enc = null;
  for (const x of a) {
    if (typeof x === 'string') enc = x;
    else if (x && typeof x === 'object' && x.encoding) enc = x.encoding;
  }
  if (enc) return String(str);
  return Buffer.from('﻿' + String(str), 'utf16le');
}
try {
  const cp = require('child_process');
  for (const m of ['execSync', 'execFileSync']) {
    const o = cp[m];
    cp[m] = function (...a) {
      const cmd = m === 'execSync' ? String(a[0]) : String(a[0]) + ' ' + (Array.isArray(a[1]) ? a[1].join(' ') : '');
      const f = fakeFor(cmd);
      if (f === null) return o.apply(this, a);
      if (isPipeCmd(cmd)) {
        try {
          const r = o.apply(this, a);
          if (typeof r === 'string') { if (validPipe(r)) return r; }
          else if (Buffer.isBuffer(r)) { if (decodeReal(r) !== null) return r; }
          else if (r) return r;
        } catch (e) { /* fall through to fake */ }
        return asRet(f, a);
      }
      try { return o.apply(this, a); }
      catch (e) { return asRet(f, a); }
    };
  }
  const oSS = cp.spawnSync;
  cp.spawnSync = function (...a) {
    const cmd = String(a[0]) + ' ' + (Array.isArray(a[1]) ? a[1].join(' ') : '');
    const f = fakeFor(cmd);
    if (f === null) return oSS.apply(this, a);
    const opts = (a.length > 2 && typeof a[2] === 'object') ? a[2] : (Array.isArray(a[1]) ? {} : (a[1] || {}));
    const mkFake = () => {
      const out = opts.encoding ? String(f) : Buffer.from('﻿' + String(f), 'utf16le');
      const errEmpty = opts.encoding ? '' : Buffer.alloc(0);
      return { pid: 0, output: [null, out, errEmpty], stdout: out, stderr: errEmpty, status: 0, signal: null };
    };
    try {
      const r = oSS.apply(this, a);
      if (!r || r.error || r.status !== 0) return mkFake();
      if (isPipeCmd(cmd)) {
        const so = r.stdout;
        const ok = typeof so === 'string' ? validPipe(so) : (Buffer.isBuffer(so) ? decodeReal(so) !== null : !!so);
        if (!ok) return mkFake();
      }
      return r;
    } catch (e) { return mkFake(); }
  };
} catch (e) {}
// os: real values first, fake only when missing
try {
  const os = require('os');
  const oNI = os.networkInterfaces;
  os.networkInterfaces = function () {
    try {
      const r = oNI.apply(this, arguments);
      if (r && Object.keys(r).length) return r;
    } catch (e) {}
    return {
      'Ethernet0': [{ address: '192.168.1.100', netmask: '255.255.255.0', family: 'IPv4', mac: FAKE_MAC, internal: false, cidr: '192.168.1.100/24' }],
      'Loopback Pseudo-Interface 1': [{ address: '127.0.0.1', netmask: '255.0.0.0', family: 'IPv4', mac: '00:00:00:00:00:00', internal: true, cidr: '127.0.0.1/8' }]
    };
  };
  const oHN = os.hostname;
  os.hostname = function () {
    try { const r = oHN.apply(this, arguments); if (r) return r; } catch (e) {}
    return FAKE_HOST;
  };
} catch (e) {}
