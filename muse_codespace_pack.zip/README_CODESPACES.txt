MK-MUSE IN THE CLOUD (nothing installs on your phone)
====================================================
Your phone only opens a browser. The tool runs on
GitHub's free computer (Codespaces) with Wine.

1. Phone browser -> github.com -> + -> New
   repository. Name: muse-run. PRIVATE (keep it
   private!). Create. (Skip README/gitignore.)
2. Inside the repo: Add file -> Upload files ->
   pick muse_codespace_pack.zip -> Commit changes.
3. Green Code button -> Codespaces tab ->
   Create codespace on main. Wait till it loads
   (minutes). Open a terminal: menu -> Terminal
   -> New Terminal.
4. Paste this ONE line, Enter, wait ~10 min:
     unzip -o -q muse_codespace_pack.zip && bash setup.sh
   Then run the tool (every session):
     bash run.sh
   The Muse menu appears IN that terminal. Done.

NOTES: first bash run.sh is slow (1-3 min), next
runs faster. When finished: codespaces menu (...
next to it) -> Stop codespace, saves free hours.
Stuck anywhere: send step number + the red lines.
